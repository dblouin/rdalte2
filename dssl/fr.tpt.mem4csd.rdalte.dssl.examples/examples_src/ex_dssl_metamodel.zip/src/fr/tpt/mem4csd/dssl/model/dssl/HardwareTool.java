/**
 */
package fr.tpt.mem4csd.dssl.model.dssl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hardware Tool</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.tpt.mem4csd.dssl.model.dssl.DsslPackage#getHardwareTool()
 * @model
 * @generated
 */
public interface HardwareTool extends Tool {
} // HardwareTool
