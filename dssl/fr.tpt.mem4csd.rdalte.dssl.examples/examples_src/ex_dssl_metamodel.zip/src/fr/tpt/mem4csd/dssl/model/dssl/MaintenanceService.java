/**
 */
package fr.tpt.mem4csd.dssl.model.dssl;

import org.eclipse.sirius.viewpoint.description.IdentifiedElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Maintenance Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.tpt.mem4csd.dssl.model.dssl.DsslPackage#getMaintenanceService()
 * @model
 * @generated
 */
public interface MaintenanceService extends IdentifiedElement {
} // MaintenanceService
