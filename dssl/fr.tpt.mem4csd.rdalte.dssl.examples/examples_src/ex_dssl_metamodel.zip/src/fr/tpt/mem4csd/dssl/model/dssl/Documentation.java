/**
 */
package fr.tpt.mem4csd.dssl.model.dssl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Documentation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.tpt.mem4csd.dssl.model.dssl.DsslPackage#getDocumentation()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Documentation extends EntityType {
} // Documentation
