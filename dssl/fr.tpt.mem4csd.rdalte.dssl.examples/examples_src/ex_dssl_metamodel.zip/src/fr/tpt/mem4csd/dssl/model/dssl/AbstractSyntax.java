/**
 */
package fr.tpt.mem4csd.dssl.model.dssl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Syntax</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.tpt.mem4csd.dssl.model.dssl.DsslPackage#getAbstractSyntax()
 * @model abstract="true"
 * @generated
 */
public interface AbstractSyntax extends Syntax {
} // AbstractSyntax
