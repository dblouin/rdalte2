/**
 */
package fr.tpt.mem4csd.dssl.model.dssl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model Simulator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.tpt.mem4csd.dssl.model.dssl.DsslPackage#getModelSimulator()
 * @model
 * @generated
 */
public interface ModelSimulator extends SoftwareTool {
} // ModelSimulator
