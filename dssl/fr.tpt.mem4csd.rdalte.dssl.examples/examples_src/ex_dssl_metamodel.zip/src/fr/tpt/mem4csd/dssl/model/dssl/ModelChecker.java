/**
 */
package fr.tpt.mem4csd.dssl.model.dssl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model Checker</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.tpt.mem4csd.dssl.model.dssl.DsslPackage#getModelChecker()
 * @model
 * @generated
 */
public interface ModelChecker extends SoftwareTool {
} // ModelChecker
