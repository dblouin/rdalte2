/**
 */
package fr.tpt.mem4csd.dssl.model.dssl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Work Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.tpt.mem4csd.dssl.model.dssl.DsslPackage#getWorkPlace()
 * @model
 * @generated
 */
public interface WorkPlace extends EntityType {
} // WorkPlace
