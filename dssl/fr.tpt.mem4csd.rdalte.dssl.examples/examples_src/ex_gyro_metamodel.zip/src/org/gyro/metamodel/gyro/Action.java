/**
 */
package org.gyro.metamodel.gyro;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gyro.metamodel.gyro.GyroPackage#getAction()
 * @model abstract="true"
 * @generated
 */
public interface Action extends Node {
} // Action
