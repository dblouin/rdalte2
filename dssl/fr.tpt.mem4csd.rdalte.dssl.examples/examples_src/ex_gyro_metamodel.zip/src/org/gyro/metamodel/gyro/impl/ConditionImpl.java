/**
 */
package org.gyro.metamodel.gyro.impl;

import org.eclipse.emf.ecore.EClass;

import org.gyro.metamodel.gyro.Condition;
import org.gyro.metamodel.gyro.GyroPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ConditionImpl extends ActionImpl implements Condition {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConditionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GyroPackage.Literals.CONDITION;
	}

} //ConditionImpl
