/**
 */
package org.gyro.metamodel.gyro;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Priority</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gyro.metamodel.gyro.GyroPackage#getPriority()
 * @model
 * @generated
 */
public interface Priority extends Behavior {
} // Priority
