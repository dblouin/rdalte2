/**
 */
package org.gyro.metamodel.gyro.impl;

import org.eclipse.emf.ecore.EClass;

import org.gyro.metamodel.gyro.GyroPackage;
import org.gyro.metamodel.gyro.Parallel;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Parallel</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ParallelImpl extends BehaviorImpl implements Parallel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ParallelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GyroPackage.Literals.PARALLEL;
	}

} //ParallelImpl
