/**
 */
package org.gyro.metamodel.gyro;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sequential</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gyro.metamodel.gyro.GyroPackage#getSequential()
 * @model
 * @generated
 */
public interface Sequential extends Behavior {
} // Sequential
