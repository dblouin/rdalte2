/**
 */
package org.gyro.metamodel.gyro.impl;

import org.eclipse.emf.ecore.EClass;

import org.gyro.metamodel.gyro.Actuate;
import org.gyro.metamodel.gyro.GyroPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Actuate</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ActuateImpl extends ActionImpl implements Actuate {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActuateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GyroPackage.Literals.ACTUATE;
	}

} //ActuateImpl
