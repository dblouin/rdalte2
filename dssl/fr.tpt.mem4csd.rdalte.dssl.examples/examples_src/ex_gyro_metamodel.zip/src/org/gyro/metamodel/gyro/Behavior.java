/**
 */
package org.gyro.metamodel.gyro;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gyro.metamodel.gyro.GyroPackage#getBehavior()
 * @model abstract="true"
 * @generated
 */
public interface Behavior extends Node {
} // Behavior
